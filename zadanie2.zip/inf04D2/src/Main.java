//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("Licznik przed tworzeniem: " + Egzaminator.getCałkowitoliczbowe());
        System.out.println("----Tworzę egzaminatora #1----");
        Egzaminator eg = new Egzaminator("Anna", "Nowak", Specjalizacja.INF02);
        System.out.println(eg);
        System.out.println("Licznik teraz: " + Egzaminator.getCałkowitoliczbowe());
        System.out.println("----Tworzę egzaminatora #2----");
        Egzaminator eg2 = new Egzaminator("Anna", "Nowak", Specjalizacja.INF04);
        System.out.println(eg2);
        System.out.println("Licznik teraz: " + Egzaminator.getCałkowitoliczbowe());
        System.out.println("----Tworzę egzaminatora #3----");
        Egzaminator eg3 = new Egzaminator("Anna", "Nowak", Specjalizacja.INF03);
        System.out.println(eg3);
        System.out.println("Licznik po zakończeniu: " + Egzaminator.getCałkowitoliczbowe());
        System.out.println("Różnica ID: obj 2 - obj 1 = " + (eg2.getId() - eg.getId()));
    }
}