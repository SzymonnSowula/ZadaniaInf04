enum Specjalizacja {
    INF02("INF.02"),
    INF03("INF.03"),
    INF04("INF.04");

    private String nazwa;

    Specjalizacja(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getNazwa() {
        return nazwa;
    }
}


public class Egzaminator {
    private static int całkowitoliczbowe = 0;
    private final int id;
    public String imie;
    public String nazwisko;
    private Specjalizacja specjalizacja;


    public Egzaminator(String imie, String nazwisko, Specjalizacja specjalizacja) {
        całkowitoliczbowe++;
        this.id = całkowitoliczbowe;
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.specjalizacja = specjalizacja;
    }

    public int getId() {
        return id;
    }

    public static int getCałkowitoliczbowe() {
        return całkowitoliczbowe;
    }

    @Override
    public String toString() {
        return "[ID:00" + id + "]" +
                " " + imie +
                " " + nazwisko +
                " | " + specjalizacja + "\n";

    }
}
