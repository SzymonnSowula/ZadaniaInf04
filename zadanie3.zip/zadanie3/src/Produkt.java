public class Produkt {
    private String nazwa;
    private double cena;
    private int ilosc;
    private String kodPartii;

    public Produkt(String nazwa, double cena, int ilosc, String kodPartii) {
        this.nazwa = nazwa;
        this.cena = cena;
        this.ilosc = ilosc;
        this.kodPartii = kodPartii;
    }

    public String getNazwa() {
        return nazwa;
    }

    public double getCena() {
        return cena;
    }

    public int getIlosc() {
        return ilosc;
    }

    public String getKodPartii() {
        return kodPartii;
    }

    public boolean czyKodPoprawny() {
        if (kodPartii == null || !kodPartii.matches("\\d{11}")) {
            return false;
        }

        int oczekiwanaCyfra = obliczCyfreKontrolna();
        int rzeczywistaCyfra = Character.getNumericValue(kodPartii.charAt(10));

        return oczekiwanaCyfra == rzeczywistaCyfra;
    }

    private int obliczCyfreKontrolna() {
        int[] wagi = {1, 3, 7, 9, 1, 3, 7, 9, 1, 3};
        int suma = 0;

        for (int i = 0; i < 10; i++) {
            int cyfra = Character.getNumericValue(kodPartii.charAt(i));
            suma += cyfra * wagi[i];
        }

        int reszta = suma % 10;

        if (reszta == 0) {
            return 0;
        }

        return 10 - reszta;
    }

    public String utworzEtykiete() {
        String bezDuplikatow = usunSasiadujaceDuplikaty(nazwa);
        return zamienSamogloskiNaGwiazdki(bezDuplikatow);
    }

    private String usunSasiadujaceDuplikaty(String tekst) {
        if (tekst.isEmpty()) {
            return tekst;
        }

        StringBuilder wynik = new StringBuilder();
        wynik.append(tekst.charAt(0));

        for (int i = 1; i < tekst.length(); i++) {
            if (tekst.charAt(i) != tekst.charAt(i - 1)) {
                wynik.append(tekst.charAt(i));
            }
        }

        return wynik.toString();
    }

    private String zamienSamogloskiNaGwiazdki(String tekst) {
        return tekst.replaceAll("(?i)[aeiouąęó]", "*");
    }

    @Override
    public String toString() {
        return nazwa + " | " + cena + " zł | " + ilosc + " szt | kod: " + kodPartii;
    }
}
