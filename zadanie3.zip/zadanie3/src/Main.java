import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Produkt> produkty = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\szymo\\IdeaProjects\\zadanie3\\src\\produkty.txt"))) {

            String linia;

            while ((linia = br.readLine()) != null) {

                String[] dane = linia.split(";");

                String nazwa = dane[0];
                String cenaTekst = dane[1];
                String iloscTekst = dane[2];
                String kod = dane[3];

                try {
                    double cena = Double.parseDouble(cenaTekst.replace(",", "."));
                    int ilosc = Integer.parseInt(iloscTekst);

                    Produkt p = new Produkt(nazwa, cena, ilosc, kod);
                    produkty.add(p);

                } catch (NumberFormatException e) {
                    System.out.println("[POMINIĘTO] " + nazwa +
                            " — błędna cena: \"" + cenaTekst + "\"");
                }
            }

        } catch (IOException e) {
            System.out.println("Błąd odczytu pliku!");
        }

        System.out.println("\nWczytano " + produkty.size() + " produktów.");

        System.out.println("\nProdukty z POPRAWNYM kodem:");

        double suma = 0;

        for (Produkt p : produkty) {

            if (p.czyKodPoprawny()) {
                System.out.println(p);

                double wartosc = p.getCena() * p.getIlosc();
                suma = suma + wartosc;
            }
        }

        System.out.println("\nProdukty z BŁĘDNYM kodem:");

        for (Produkt p : produkty) {

            if (!p.czyKodPoprawny()) {
                System.out.println(p.getNazwa());
            }
        }

        System.out.println("\nEtykiety produktów:");

        for (Produkt p : produkty) {

            if (p.czyKodPoprawny()) {
                System.out.println(p.getNazwa() + " -> " + p.utworzEtykiete());
            }
        }

        System.out.println("\nWartość magazynowa poprawnych produktów:");
        System.out.println(suma + " zł");
    }
}