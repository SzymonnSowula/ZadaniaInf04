import java.time.LocalDate;

public class FlotaManagement {
    //inicjalizacja zmiennych
    private String numer_rejestracji;
    private String rodzaj_pojazdu;
    private int rok_produkcji;
    private double przebieg;
    int aktualny_rok = LocalDate.now().getYear();
    //konstruktor który określa wszystkie wymagania wedle reguł
    public FlotaManagement(String numer_rejestracji, String rodzaj_pojazdu, int rok_produkcji, double przebieg) {
        this.numer_rejestracji = numer_rejestracji;
        if(rodzaj_pojazdu.equals("osobowy") || rodzaj_pojazdu.equals("dostawczy") || rodzaj_pojazdu.equals("motocykl")){
            this.rodzaj_pojazdu = rodzaj_pojazdu;
        }else {
            System.out.println("Wpisz poprawny rodzaj samochodu");
        }

        if(rok_produkcji >=1900 && rok_produkcji <= aktualny_rok){
            this.rok_produkcji = rok_produkcji;
        }else System.out.println("Błąd wprowadzenia roku produkcji.");

        if (przebieg >= 0){
            this.przebieg = przebieg;
        }
        else System.out.println("Nie może być ujemny");
    }
    //funkcja do sprawdzenia czy pojazd wymaga serwisu
    public boolean czy_wymaga_serwisu() {
        int wiek_pojazdu = aktualny_rok - rok_produkcji;
        if (wiek_pojazdu > 5 || przebieg > 20000) {
            return true;
        }
        return false;
    }
    //funkcja do ustawiania przebiegu z walidacją czy nie jest ujemny
    public void setPrzebieg(double przebieg) {
        if (przebieg >= 0){
            this.przebieg = przebieg;
        }
        else System.out.println("Przebieg nie może być ujemny");
    }

    public String getNumer_rejestracji() {
        return numer_rejestracji;
    }

    public String getRodzaj_pojazdu() {
        return rodzaj_pojazdu;
    }

    public int getRok_produkcji() {
        return rok_produkcji;
    }

    public double getPrzebieg() {
        return przebieg;
    }


    @Override
    public String toString() {
        return "[" + numer_rejestracji + "] " +
                rodzaj_pojazdu + ", " +
                rok_produkcji + "r., " +
                przebieg + " km — SERWIS: " +
                (czy_wymaga_serwisu() ? "TAK" : "NIE");
    }
}

