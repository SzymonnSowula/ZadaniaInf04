import java.util.Scanner;

public class AlgorytmEuklidea {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Wprowadź liczbę a:");
        int a = sc.nextInt();
        System.out.println("Wprowadź liczbę b:");
        int b = sc.nextInt();
//        if(a!=b){
//            if(a>b) {
//            a -=b;
//
//            }else{
//                b -=a;
//
//            }
//        }else {
//            System.out.println(a);
//        }
        while(a!=b){
            if(a>b) {
            a -=b;
            }else{
                b -=a;
            }
//            System.out.println(a);
        }
        System.out.println(a);
        sc.close();
    }
}
