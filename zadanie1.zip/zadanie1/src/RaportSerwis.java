import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RaportSerwis {
    // Sortuje listę pojazdów po roku produkcji używająć Collections
    public static void sortAll(ArrayList<FlotaManagement> lista) {

        Collections.sort(lista, new Comparator<FlotaManagement>() {
            @Override
            public int compare(FlotaManagement o1, FlotaManagement o2) {
                return Integer.compare(
                        o1.getRok_produkcji(),
                        o2.getRok_produkcji()
                );
            }
        });
    }
    // Wyświetla raport pojazdów wymagających serwisu
    public static void showRaport(ArrayList<FlotaManagement> lista) {

        int licznikSerwis = 0;

        System.out.println("=== RAPORT SERWISOWY ===");
        System.out.println("Data raportu: " + LocalDate.now());
        System.out.println();

        for (FlotaManagement pojazd : lista) {

            if (pojazd.czy_wymaga_serwisu()) {
                System.out.println(pojazd);
                licznikSerwis++;
            }
        }

        double procent = ((double) licznikSerwis / lista.size()) * 100;

        System.out.println();
        System.out.println("Pojazdy wymagające serwisu: " + licznikSerwis);
        System.out.println("Procent floty: " + procent + "%");
    }
}