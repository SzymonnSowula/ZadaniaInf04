import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
public class Main {
    //Zadanie dodatkowe funckja do tworzenia obiektu z stringa
    public static FlotaManagement utworzString(String txt) {

        String[] tablicaDanych = txt.split(";");
        String numer = tablicaDanych[0];
        String rodzaj = tablicaDanych[1];
        int rok = Integer.parseInt(tablicaDanych[2]);
        double przebieg = Double.parseDouble(tablicaDanych[3]);

        return new FlotaManagement(numer,rodzaj,rok,przebieg);
    }
    public static void main(String[] args) {

    FlotaManagement p1 = utworzString("K55314;osobowy;2008;270000");
    FlotaManagement p2 = new FlotaManagement("WZB1231", "osobowy", 2022, 15230);
    System.out.println(p1);
    System.out.println(p2);
    ArrayList<FlotaManagement> lista = new ArrayList<>();

                lista.add(new FlotaManagement("WZ12345", "osobowy", 2026, 15230.0));
                lista.add(new FlotaManagement("KR99887", "dostawczy", 2014, 48120.5));
                lista.add(new FlotaManagement("WA00001", "motocykl", 1999, 2300.0));
                lista.add(new FlotaManagement("GD44556", "osobowy", 2025, 12000.0));
                lista.add(new FlotaManagement("PO77889", "dostawczy", 2016, 25000.0));
                lista.add(new FlotaManagement("LU33321", "motocykl", 2022, 8000.0));

                RaportSerwis.sortAll(lista);
                RaportSerwis.showRaport(lista);
            }
        }