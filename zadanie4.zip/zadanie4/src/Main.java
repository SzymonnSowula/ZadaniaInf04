public class Main {
    public static void main(String[] args) {

        Konto[] konta = new Konto[3];

        konta[0] = new Konto("PL001", 1000);
        konta[1] = new kontoOszczednosciowe("PL002", 1000);
        konta[2] = new KontoPremium("PL003", 1000, 500);

        for (Konto konto : konta) {

            System.out.println("\n---" + konto.getNumerKonta() + "---");

            konto.wplac(1000);

            boolean czyWyplacono = konto.wyplac(1200);

            if (!czyWyplacono) {
                System.out.println("Wypłata nie została wykonana.");
            }

            if (konto instanceof KontoPremium) {
                KontoPremium premium = (KontoPremium) konto;
                premium.naliczOdsetkiKarne();
            }

            System.out.println("Końcowe saldo: " + konto.getSaldo() + " zł");
        }

        double suma = sumaDodatnichSald(konta);
        System.out.println("\nSuma dodatnich sald: " + suma + " zł");
    }

    public static double sumaDodatnichSald(Konto[] konta) {
        double suma = 0;

        for (Konto konto : konta) {
            if (konto.getSaldo() > 0) {
                suma = suma + konto.getSaldo();
            }
        }

        return suma;
    }
}