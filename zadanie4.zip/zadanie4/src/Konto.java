public class Konto {
    protected String numerKonta;
    protected double saldo;

    public Konto(String numerKonta, double saldo) {
        this.numerKonta = numerKonta;
        this.saldo = saldo;
    }

    public boolean wplac(double kwota) {
        if (kwota <= 0) {
            System.out.println("Błędna kwota wpłaty.");
            return false;
        }

        saldo = saldo + kwota;
        System.out.println("Wpłata " + kwota + " zł -> saldo: " + saldo + " zł");
        return true;
    }

    public boolean wyplac(double kwota) {
        if (saldo - kwota < 0) {
            System.out.println("Brak środków na koncie.");
            return false;
        }

        saldo = saldo - kwota;
        System.out.println("Wypłata " + kwota + " zł -> saldo: " + saldo + " zł");
        return true;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getNumerKonta() {
        return numerKonta;
    }

    @Override
    public String toString() {
        return "[Konto] " + numerKonta + " | saldo: " + saldo + " zł";
    }
}