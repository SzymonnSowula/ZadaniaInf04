public class kontoOszczednosciowe extends Konto {

    public kontoOszczednosciowe(String numerKonta, double saldo) {
        super(numerKonta, saldo);
    }

    @Override
    public boolean wplac(double kwota) {
        if (kwota <= 0) {
            System.out.println("Błędna kwota wpłaty.");
            return false;
        }

        double bonus = kwota * 0.01;
        saldo = saldo + kwota + bonus;

        System.out.println("Wpłata " + kwota + " zł (+1%) -> saldo: " + saldo + " zł");
        return true;
    }

    @Override
    public boolean wyplac(double kwota) {
        double prowizja = 5;
        double razem = kwota + prowizja;

        if (saldo - razem < 0) {
            System.out.println("Brak środków. Wypłata + prowizja przekracza saldo.");
            return false;
        }

        saldo = saldo - razem;
        System.out.println("Wypłata " + kwota + " zł (+5 zł prowizji) -> saldo: " + saldo + " zł");
        return true;
    }

    @Override
    public String toString() {
        return "[KontoOszczednosciowe] " + numerKonta + " | saldo: " + saldo + " zł";
    }
}