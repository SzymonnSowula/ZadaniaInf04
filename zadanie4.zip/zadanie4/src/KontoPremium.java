public class KontoPremium extends Konto {
    private double limitDebetu;

    public KontoPremium(String numerKonta, double saldo, double limitDebetu) {
        super(numerKonta, saldo);
        this.limitDebetu = limitDebetu;
    }

    @Override
    public boolean wyplac(double kwota) {
        if (saldo - kwota < -limitDebetu) {
            System.out.println("Przekroczono limit debetu.");
            return false;
        }

        saldo = saldo - kwota;
        System.out.println("Wypłata " + kwota + " zł -> saldo: " + saldo + " zł");
        return true;
    }

    public void naliczOdsetkiKarne() {
        if (saldo < 0) {
            double odsetki = Math.abs(saldo) * 0.10;
            saldo = saldo - odsetki;
            System.out.println("Odsetki karne: " + odsetki + " zł");
        } else {
            System.out.println("Odsetki karne: 0 zł, saldo dodatnie");
        }
    }

    @Override
    public String toString() {
        return "[KontoPremium] " + numerKonta + " | saldo: " + saldo +
                " zł | limit: " + limitDebetu + " zł";
    }
}